Ryan Ritchie
101114165


The pages are split into a welcome page, a order form page, and a statistics page
All orders made will influence the data on the statistics page

The server is run throughNode.js, and to do so, you will go to the directory containing all the files, then in the command line, use the line:
						node server.js
The server will now be running on port 3000, and going into your browser and navigating to:
						localhost:3000
you will see the home page, from there you can navigate the full program