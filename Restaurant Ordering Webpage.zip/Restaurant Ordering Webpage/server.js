//Ryan Ritchie
let http = require('http');
let fs = require('fs');
let path = require('path');
const pug = require('pug');
var response;
//set the renders for each different pug page
const renderHome = pug.compileFile("./home.pug");
const renderOrder = pug.compileFile("./orderform.pug");
const renderStats = pug.compileFile("./stats.pug");
let restaurant = [];

let orders = [];
var restaurantNames = fs.readdirSync('./restaurants');//get the restaurants JSON files
for(let i =0;i<restaurantNames.length;i++){//loop to pull the restaurants information
				restaurant.push(JSON.parse(fs.readFileSync('./restaurants/' + restaurantNames[i])));
			}
//404 Sending function 
function send404(response) {
	response.writeHead(404, { 'Content-Type': 'text/plain' });
	response.write('Error 404: Resource not found.');
	response.end();
}

let server = http.createServer(function (req, res) {
	if (req.method === 'GET') {//if the request method is GET
		let fileurl;
		if (req.url == '/'){//if the user wants to go to the home page
			
			let content = renderHome({});//sync the home pug page
			res.statusCode = 200;
			res.setHeader("Content-Type", "text/html");
			res.end(content);//send the response to the client, opening the home page
		}else if(req.url == '/orderform'){//if the user requests to go to the order page
			let content = renderOrder({restaurants:restaurant});//render the order form
			res.statusCode = 200;
			res.setHeader("Content-Type","text/html");
			res.end(content);//send the response to the client, opening the ordering page
		}else if(req.url == '/restaurants'){//if the uer requests to receive the restaurants
			res.writeHead(200,{'content-type':"application/json"});//send the restaurants as the response
			res.end(JSON.stringify(restaurant))
		}else if(req.url == '/client.js'){//if the client.js file is requested
			fs.readFile("client.js", function(err, data){//read the files information
				if(err){//if an error occurs, send a server error
					send500(response);
					return;
				}
				//send the success response with the javascript file
				res.statusCode = 200;
				res.end(data);
				return;
			});
		}else if(req.url == '/add.jpg'){//if the add image is requested
			fs.readFile("add.jpg", function(err, data){//get the images contents
				if(err){//if an error occurs, then send a 500 response
					send500(response);
					return;
				}
				//send the image and 200 status to the client
				res.setHeader('Content-Type',"image/jpeg");
				res.statusCode = 200;
				res.end(data);
				return;
			});
		}else if(req.url == '/remove.jpg'){//i the remove image is requested
		fs.readFile("remove.jpg", function(err, data){//ge tthe contents of the image
			if(err){//if an error occurs, send a server error code
				send500(response);
				return;
			}//send a response with the image 
			res.setHeader('Content-Type',"image/jpeg");
			res.statusCode = 200;
			res.end(data);
			return;
		});
		}else if(req.url == "/stats"){//if the user requests to go to te stats page
			let stats = [];
			let orderHigh;
			//loop through each restaurants order information
			for(let i=0;i<orders.length;i++){
				let highestOrder = 0;
				for(key in orders[i]){//loop through the current restaurants orders to find the most ordered item
					//if the current order was ordered more than the highest, then set this to the new highest
					if(orders[i][key]>highestOrder && key != "cost" && key != "restaurant"){	highestOrder = orders[i][key];	orderHigh = key;}
				}
				let avg = (orders[i]["cost"]/orders[i]["numOrders"]).toFixed(2);//get the average cost of an order for the current restaurant
				stats.push({"restaurant":orders[i]["restaurant"],"numOrders":orders[i]["numOrders"],"highest":orderHigh,"averageCost":avg})//add to the array to send to the client
			}
			let content = renderStats({stats:stats});//render the stats pug file
			res.statusCode = 200;//set the status code
			res.setHeader("Content-Type","text/html");
			res.end(content);		
		}else{//any other request will be met with a 404 response
			send404(res);
		}
	}else if(req.method == "POST"){//if the request method is a POST, sending info to the server
		let body = ""
			req.on('data', (chunk) => {//collect the JSON string from the client
				body += chunk;
			})
			//when the full string is read, we now will parse it and use the data in the object
			req.on('end', () => {
				let position = -1;
				let newOrder = JSON.parse(body);//parse the JSON string into an order object
					//loop to go through the previous orders
					for(let i = 0;i<orders.length;i++){
						//if this restaurant has already been ordered from, then remember it's spot in the array
						if(newOrder["restaurant"] === orders[i]["restaurant"]){
							position = i;
							break;
						}
					}
					//if this is the first order from the restaurant, then add the order and set the number of orders to one
					if(position === -1){
						orders.push(newOrder);
						orders[orders.length-1]["numOrders"]=1;
					}else{
						//loop through the new order
						for(key in newOrder){
							//if the requested item has already been ordered, add to it's total
							if(orders[position].hasOwnProperty(key) && key != "restaurant" && key != "cost"){
								orders[position][key]++;
							}else{//if it hasn't been, then set the number of items to 1
								if(key != "restaurant" && key != "cost"){//make sure it's not the corst or name
									orders[position][key]=1;
								}else if(key === "cost"){
									//add the cost to the order
									orders[position][key]+=newOrder[key];								}
							}
						}
						//add an order to the counter
						orders[position]["numOrders"]++
						
					}
					//send the response to the client
					console.log(newOrder);
					res.writeHead(200,);
					res.end();
					return;
				
			})
	}else{ //if not a GET request, send 404
		send404(res);
	}
});
//set the port to listen to
server.listen(3000);
console.log('server running on port 3000');